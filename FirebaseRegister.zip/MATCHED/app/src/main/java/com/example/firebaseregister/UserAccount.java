package com.example.firebaseregister;

public class UserAccount {

    public UserAccount() {
    }
    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }
    public String idToken;
    public void setPassword(String password) {this.password = password; }
    public String password;
}