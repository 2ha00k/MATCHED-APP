package com.example.firebaseregister;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    BoardFragment boardFragment;
    ChatFragment chatFragment;
    MyFragment myFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boardFragment = new BoardFragment();
        chatFragment = new ChatFragment();
        myFragment = new MyFragment();

        getSupportFragmentManager().beginTransaction().replace(R.id.containers, boardFragment).commit();
        NavigationBarView navigationBarView = findViewById(R.id.bottom_navigationview);
        navigationBarView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.board) {
                getSupportFragmentManager().beginTransaction().replace(R.id.containers, boardFragment).commit();
                return true;
            } else if (itemId == R.id.chat) {
                getSupportFragmentManager().beginTransaction().replace(R.id.containers, chatFragment).commit();
                return true;
            } else if (itemId == R.id.my) {
                getSupportFragmentManager().beginTransaction().replace(R.id.containers, myFragment).commit();
                return true;
            }
            return false;
        });
    }
}



